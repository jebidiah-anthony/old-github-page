Challenge Description:

	You must obtain the hidden secrets in order to see the reality.
